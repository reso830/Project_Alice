@echo off
echo Alice fixture v1.10.0
